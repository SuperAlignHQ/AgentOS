from .prompt import generate_document_type_prompt

